<?php
$version = 'test_bc471f';
$ts = (new \DateTimeImmutable())->format('Y-M-d H:i:s');
echo "Hello world $version - $ts";